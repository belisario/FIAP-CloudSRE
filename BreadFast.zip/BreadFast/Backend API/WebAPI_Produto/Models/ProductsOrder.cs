﻿namespace WebAPI_Produto.Models
{
    public class ProductsOrder
    {
        public double Price { get; set; }
        public string Name { get; set; }
        public int Quantity { get; set; }
    }
}