﻿namespace WebAPI_Produto.Models
{
    public class Product
    {
        public double Price { get; set; }
        public string Name { get; set; }
        public string URL { get; set; }
        public string Type { get; set; }
        public string Description { get; set; }

    }
}